<?php
echo password_hash("superadmin@123", PASSWORD_BCRYPT);
?>